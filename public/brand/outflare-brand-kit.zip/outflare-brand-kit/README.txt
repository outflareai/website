OUTFLARE BRAND KIT
https://outflare.ai/brand/

The Outflare logo is a two-corner mark and the lowercase "outflare"
wordmark. Every file here is the approved artwork: please don't redraw,
retype or recolour it.

WHICH FILE TO USE
svg/outflare-lockup-white.svg    Logo for dark backgrounds (use SVG first)
svg/outflare-lockup-black.svg    Logo for light backgrounds
svg/outflare-mark-*.svg          Mark only, for small or square spaces
svg/outflare-wordmark-*.svg      Name only
svg/*-currentcolor.svg           Inline SVGs that take the CSS text colour
png/, webp/                      Transparent exports in several widths
icons/                           Favicons, app icons and square avatars
social/                          1200x630 link preview image
integration/OutflareLogo.tsx     React component (lockup or mark)

RULES
- Clear space: at least a quarter of the mark's height on every side.
- Minimum size: 110px wide for the full logo; use the mark below that.
- Black on light, white on dark, with strong contrast. No other colours.
- Don't stretch, rotate, outline, add effects, round the corners, or set
  the name in a font. In text, write the name "Outflare".

COLOURS
Black #000000 · White #FFFFFF · Night #0A0A0A (dark backgrounds)

The supporting tagline on the social image is outlined from Geist Medium
(SIL Open Font License, see licenses/). The logo itself needs no font.

Questions: hello@outflare.ai
